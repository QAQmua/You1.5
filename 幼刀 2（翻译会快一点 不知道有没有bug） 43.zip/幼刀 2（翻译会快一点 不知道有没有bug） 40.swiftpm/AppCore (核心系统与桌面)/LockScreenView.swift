// MARK: - 4. LockScreenView (锁屏主视图 · 修正版)
import SwiftUI
import UIKit

struct LockScreenView: View {
    @Binding var isUnlocked: Bool
    
    @ObservedObject var wallpaperManager = WallpaperManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var lang = LanguageManager.shared
    
    var contentColor: Color {
        wallpaperManager.isLockLight ? .black : .white
    }
    
    private let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter
    }()
    
    private func localizedDateString(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: lang.currentLanguage.localeIdentifier)
        switch lang.currentLanguage {
        case .simplifiedChinese, .traditionalChinese:
            formatter.dateFormat = "EEEE, M月d日"
        case .english:
            formatter.dateFormat = "EEEE, MMMM d"
        case .japanese:
            formatter.dateFormat = "M月d日 EEEE"
        case .korean:
            formatter.dateFormat = "M월 d일 EEEE"
        }
        return formatter.string(from: date)
    }
    
    var body: some View {
        VStack {
            Image(systemName: "lock.fill")
                .font(.title2)
                .foregroundColor(contentColor)
                .padding(.top, 60) // 恢复原版的 60
            
            TimelineView(.periodic(from: .now, by: 1.0)) { context in
                VStack(spacing: 0) {
                    Text(timeFormatter.string(from: context.date))
                        .font(.system(size: 80, weight: .ultraLight, design: .rounded))
                        .foregroundColor(contentColor)
                    
                    Text(localizedDateString(for: context.date))
                        .font(.title3)
                        .fontWeight(appearance.systemFontWeight)
                        .foregroundColor(wallpaperManager.isLockLight ? Color.black.opacity(0.6) : .gray)
                }
            }
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .fontWeight(appearance.systemFontWeight)
        .background(NativeImage(data: wallpaperManager.lockScreenData).ignoresSafeArea())
        .overlay(alignment: .bottom) {
            Capsule()
                .fill(contentColor)
                .frame(width: 130, height: 5)
                .padding(.bottom, 10)
        }
        .ignoresSafeArea(.all, edges: .bottom)
        .gesture(
            DragGesture()
                .onEnded { value in
                    if value.translation.height < -50 {
                        withAnimation(.easeInOut(duration: 0.4)) {
                            isUnlocked = true
                        }
                    }
                }
        )
    }
}
