// 📄 替换文件：AppCore (核心系统与桌面)/DesktopCore.swift
// MARK: - 3. DesktopCore (桌面核心数据算法与拖拽调度 · 120Hz极速解耦丝滑版)
import SwiftUI
import UIKit

// 💡 独立高频位置发布者：仅供最上层浮层消费，彻底解放整屏桌面重绘
@MainActor
final class DragPositionTracker: ObservableObject {
    @Published var offset: CGSize = .zero
    @Published var location: CGPoint = .zero
}

@MainActor
final class DragCoordinator: ObservableObject {
    @Published var activeDraggingItem: AppItem? = nil
    @Published var activeDragSource: AppLocation? = nil
    let positionTracker = DragPositionTracker()
    
    func start(item: AppItem, source: AppLocation, location: CGPoint) {
        activeDraggingItem = item
        activeDragSource = source
        positionTracker.location = location
    }
    
    func update(location: CGPoint) {
        positionTracker.location = location
    }
    
    func reset() {
        activeDraggingItem = nil
        activeDragSource = nil
        positionTracker.location = .zero
    }
}

@MainActor
class HomeScreenViewModel: ObservableObject {
    @Published var apps: [AppItem?] = []
    @Published var dockApps: [AppItem] = []
    @Published var isEditing: Bool = false
    
    // 💡 仅在拖拽按住并顶在末页边缘时，动态激活扩页，绝不无缘无故凭空虚增
    @Published var isExpandingNewPage: Bool = false
    
    let pageSize: Int = 24
    private let gridKey = "App_HomeScreen_Grid24_Data_Clean"
    private let dockKey = "App_HomeScreen_Dock4_Data_Clean"
    private let saveQueue = DispatchQueue(label: "com.app.homescreen.saveQueue", qos: .utility)
    
    init() { loadData() }
    
    func isPageEmpty(_ page: Int) -> Bool {
        let start = page * pageSize
        let end = min(start + pageSize, apps.count)
        if start < end {
            let hasApp = apps[start..<end].contains(where: { $0 != nil })
            if hasApp { return false }
        }
        let hasWidget = WidgetRegistry.shared.activeManagers.contains { $0.isAddedToDesktop && $0.widgetPage == page }
        return !hasWidget
    }
    
    /// 统计当前实际有内容（App 或 Widget）的最大物理页数
    func totalPagesWithoutExtra() -> Int {
        var maxPage = 0
        if let lastIndex = apps.lastIndex(where: { $0 != nil }) {
            maxPage = max(maxPage, lastIndex / pageSize)
        }
        for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop {
            maxPage = max(maxPage, widget.widgetPage)
        }
        return max(1, maxPage + 1)
    }
    
    /// 💡 真实页面数量：平时严格实事求是（有几页就几页），仅在边缘拖拽扩页时动态临时提供新页
    func totalPages() -> Int {
        let contentPages = totalPagesWithoutExtra()
        if isExpandingNewPage {
            return contentPages + 1
        }
        return contentPages
    }
    
    /// 激活扩充一页并分配好内存槽位
    func triggerExpandNewPage() {
        isExpandingNewPage = true
        ensureCapacity(upToSlot: (totalPagesWithoutExtra() + 1) * pageSize)
    }
    
    func ensureCapacity(upToSlot slot: Int) {
        while apps.count <= slot {
            apps.append(nil)
        }
    }
    
    /// 💡 整理与空页自动销毁引擎
    func compactPages() {
        isExpandingNewPage = false
        
        // 1. 中间空页扫描：若前面的某页被全部清空，后面内容向前顺移
        var p = 0
        while p < totalPagesWithoutExtra() - 1 {
            if isPageEmpty(p) {
                let start = p * pageSize
                let end = min(start + pageSize, apps.count)
                if start < apps.count {
                    apps.removeSubrange(start..<end)
                }
                for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop && widget.widgetPage > p {
                    widget.widgetPage -= 1
                }
            } else {
                p += 1
            }
        }
        
        // 2. 尾部空格子修剪：超出实际内容页的空格子立刻销毁，绝不留无用空页
        let activePages = totalPagesWithoutExtra()
        let neededSlots = activePages * pageSize
        while apps.count > neededSlots && apps.last == nil {
            apps.removeLast()
        }
        while apps.count < neededSlots {
            apps.append(nil)
        }
        
        evictAppsUnderWidgets()
        saveApps()
    }
    
    func getCoveredIndices() -> Set<Int> {
        var covered = Set<Int>()
        for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop {
            let p = widget.widgetPage
            let r = widget.widgetRow
            let c = widget.widgetCol
            let pageBase = p * pageSize
            for i in 0..<widget.sizeRows {
                for j in 0..<widget.sizeCols {
                    let slotRow = r + i
                    let slotCol = c + j
                    if slotRow < 6 && slotCol < 4 {
                        let slot = pageBase + slotRow * 4 + slotCol
                        covered.insert(slot)
                    }
                }
            }
        }
        return covered
    }
    
    /// 💡 寻位算法：优先将组件放置在用户当前所在页（preferPage），放得下就放当前页，放不下才顺延扩页
    func findAvailableSlot(forRows neededRows: Int, forCols neededCols: Int, preferPage: Int = 0) -> (page: Int, row: Int, col: Int) {
        let contentPages = totalPagesWithoutExtra()
        let candidateRows: [Int] = (neededRows >= 4) ? [0, 1, 2] : [0, 1, 2, 3, 4]
        let candidateCols: [Int] = (neededCols >= 4) ? [0] : [0, 2]
        
        var pageOrder: [Int] = [min(preferPage, max(0, contentPages - 1))]
        for p in 0..<contentPages where p != pageOrder[0] {
            pageOrder.append(p)
        }
        
        for p in pageOrder {
            var occupied = Array(repeating: Array(repeating: false, count: 4), count: 6)
            for widget in WidgetRegistry.shared.activeManagers where widget.isAddedToDesktop && widget.widgetPage == p {
                let wR = widget.widgetRow
                let wC = widget.widgetCol
                for i in 0..<widget.sizeRows {
                    for j in 0..<widget.sizeCols {
                        let r = wR + i
                        let c = wC + j
                        if r < 6 && c < 4 { occupied[r][c] = true }
                    }
                }
            }
            
            for r in candidateRows {
                for c in candidateCols {
                    if r + neededRows <= 6 && c + neededCols <= 4 {
                        var canFit = true
                        for i in 0..<neededRows {
                            for j in 0..<neededCols {
                                if occupied[r + i][c + j] { canFit = false; break }
                            }
                            if !canFit { break }
                        }
                        if canFit { return (page: p, row: r, col: c) }
                    }
                }
            }
        }
        
        return (page: contentPages, row: 0, col: 0)
    }
    
    func evictAppsUnderWidgets(vacatedSlots: [Int] = []) {
        let covered = getCoveredIndices()
        let neededCount = max(totalPages(), 1) * pageSize
        while apps.count < neededCount { apps.append(nil) }
        
        var displacedApps: [AppItem] = []
        for i in 0..<apps.count {
            if covered.contains(i), let item = apps[i] {
                displacedApps.append(item)
                apps[i] = nil
            }
        }
        
        for app in displacedApps {
            if let freeSlot = (0..<apps.count).first(where: { !covered.contains($0) && apps[$0] == nil }) {
                apps[freeSlot] = app
            } else {
                apps.append(app)
            }
        }
        while apps.count < pageSize { apps.append(nil) }
        saveApps()
    }
    
    func loadData() {
        let isFirstEverLaunch = UserDefaults.standard.object(forKey: gridKey) == nil && UserDefaults.standard.object(forKey: dockKey) == nil
        var loadedApps: [AppItem?] = []
        if let data = UserDefaults.standard.data(forKey: gridKey),
           let decoded = try? JSONDecoder().decode([AppItem?].self, from: data) {
            loadedApps = decoded
        }
        while loadedApps.count < pageSize { loadedApps.append(nil) }
        var loadedDock: [AppItem] = []
        if let data = UserDefaults.standard.data(forKey: dockKey),
           let decoded = try? JSONDecoder().decode([AppItem].self, from: data) {
            loadedDock = Array(decoded.prefix(4))
        } else if isFirstEverLaunch {
            loadedDock = [
                AppItem(id: "phone", title: "电话", icon: "phone.fill", colorName: "green"),
                AppItem(id: "wechat", title: "微信", icon: "message.fill", colorName: "green")
            ]
        }
        if isFirstEverLaunch {
            if loadedApps[0] == nil { loadedApps[0] = AppItem(id: "settings", title: "设置", icon: "gearshape.fill", colorName: "gray") }
            if loadedApps[1] == nil { loadedApps[1] = AppItem(id: "iscreen", title: "iScreen", icon: "square.grid.2x2.fill", colorName: "purple") }
        }
        self.apps = loadedApps
        self.dockApps = loadedDock
        let existingIds = Set(apps.compactMap { $0?.id } + dockApps.map { $0.id })
        
        // 💡 保证系统级核心应用在桌面始终存在
        let essentialApps: [AppItem] = [
            AppItem(id: "phone", title: "电话", icon: "phone.fill", colorName: "green"),
            AppItem(id: "settings", title: "设置", icon: "gearshape.fill", colorName: "gray"),
            AppItem(id: "iscreen", title: "iScreen", icon: "square.grid.2x2.fill", colorName: "purple"),
            AppItem(id: "wechat", title: "微信", icon: "message.fill", colorName: "green"),
            AppItem(id: "messages", title: "信息", icon: "message.badge.filled.fill", colorName: "green"),
            AppItem(id: "weather", title: "天气", icon: "cloud.sun.fill", colorName: "blue"),
            AppItem(id: "anonymous", title: "匿名", icon: "mask.fill", colorName: "purple"),
            AppItem(id: "qimao", title: "七猫小说", icon: "book.fill", colorName: "orange"),
            AppItem(id: "icity", title: "iCity", icon: "building.2.fill", colorName: "blue"),
            AppItem(id: "notes", title: "手记", icon: "note.text", colorName: "orange")
        ]
        let covered = getCoveredIndices()
        for essential in essentialApps {
            if !existingIds.contains(essential.id) {
                if let freeSlot = (0..<pageSize).first(where: { !covered.contains($0) && self.apps[$0] == nil }) {
                    self.apps[freeSlot] = essential
                } else {
                    self.apps.append(essential)
                }
            }
        }
        compactPages()
    }
    
    func deduplicateApps() {
        var seenIds = Set<String>()
        var uniqueDock: [AppItem] = []
        for item in dockApps {
            if !seenIds.contains(item.id) { seenIds.insert(item.id); uniqueDock.append(item) }
        }
        self.dockApps = uniqueDock
        for (index, item) in apps.enumerated() {
            if let item = item {
                if seenIds.contains(item.id) { apps[index] = nil }
                else { seenIds.insert(item.id) }
            }
        }
    }
    
    func saveApps() {
        let currentApps = self.apps
        let currentDock = self.dockApps
        let gKey = self.gridKey
        let dKey = self.dockKey
        saveQueue.async {
            if let data = try? JSONEncoder().encode(currentApps) { UserDefaults.standard.set(data, forKey: gKey) }
            if let data = try? JSONEncoder().encode(currentDock) { UserDefaults.standard.set(data, forKey: dKey) }
        }
    }
    
    func moveItem(from source: AppLocation, to destination: AppLocation) {
        guard source != destination else { return }
        let covered = getCoveredIndices()
        switch (source, destination) {
        case (.grid(let from), .grid(let to)):
            ensureCapacity(upToSlot: max(from, to))
            guard from < apps.count, to < apps.count, !covered.contains(to) else { return }
            let target = apps[to]
            apps[to] = apps[from]
            apps[from] = target
            
        case (.dock(let from), .dock(let to)):
            guard from < dockApps.count, to < dockApps.count, from != to else { return }
            let item = dockApps.remove(at: from)
            dockApps.insert(item, at: min(to, dockApps.count))
            
        case (.grid(let fromGrid), .dock(let toDock)):
            ensureCapacity(upToSlot: fromGrid)
            guard fromGrid < apps.count, let movingItem = apps[fromGrid] else { return }
            apps[fromGrid] = nil
            dockApps.removeAll(where: { $0.id == movingItem.id })
            if dockApps.count < 4 {
                let insertIndex = min(toDock, dockApps.count)
                dockApps.insert(movingItem, at: insertIndex)
            } else {
                let safeIndex = min(toDock, dockApps.count - 1)
                let targetDockItem = dockApps[safeIndex]
                dockApps[safeIndex] = movingItem
                apps[fromGrid] = targetDockItem
            }
            
        case (.dock(let fromDock), .grid(let toGrid)):
            ensureCapacity(upToSlot: toGrid)
            guard fromDock < dockApps.count, toGrid < apps.count, !covered.contains(toGrid) else { return }
            let movingItem = dockApps.remove(at: fromDock)
            if let targetExisting = apps[toGrid] {
                if !dockApps.contains(where: { $0.id == targetExisting.id }) && dockApps.count < 4 {
                    dockApps.insert(targetExisting, at: min(fromDock, dockApps.count))
                }
            }
            apps[toGrid] = movingItem
        }
        deduplicateApps()
    }
    
    func slotsForPage(_ pageIndex: Int) -> [(index: Int, item: AppItem?)] {
        let start = pageIndex * pageSize
        let end = start + pageSize
        ensureCapacity(upToSlot: end)
        return (start..<end).map { (index: $0, item: apps[$0]) }
    }
}

// MARK: - 极速微晃动画引擎（纯声明式 · 绝不跨页残留）
struct JiggleModifier: ViewModifier {
    let isEditing: Bool
    var isWidget: Bool = false
    var customDelayIndex: Int = 0
    
    @State private var isWiggling: Bool = false
    private var angle: Double { isWidget ? 0.65 : 1.15 }
    private var delay: Double { customDelayIndex.isMultiple(of: 2) ? 0.0 : 0.06 }
    
    @ViewBuilder
    func body(content: Content) -> some View {
        content
            .rotationEffect(.degrees(isEditing ? (isWiggling ? angle : -angle) : 0))
            .animation(
                isEditing
                ? Animation.easeInOut(duration: 0.13).repeatForever(autoreverses: true).delay(delay)
                : .easeInOut(duration: 0.15),
                value: isWiggling
            )
            .animation(.easeInOut(duration: 0.15), value: isEditing)
            .onAppear {
                if isEditing {
                    isWiggling = true
                } else {
                    isWiggling = false
                }
            }
            .onChange(of: isEditing) { _, editing in
                isWiggling = editing
            }
            .onChange(of: customDelayIndex) { _, _ in
                if isEditing {
                    isWiggling = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                        isWiggling = true
                    }
                }
            }
    }
}

// MARK: - 高性能位图渲染器
struct NativeImage: View {
    var data: Data?
    var body: some View {
        if let uiImage = ImageBitmapCache.shared.image(from: data) {
            Image(uiImage: uiImage).resizable().scaledToFill()
        } else {
            // 🌟 空数据时默认呈现白色底色壁纸
            Color.white
        }
    }
}

struct WidgetDeleteBadge: View {
    var body: some View {
        ZStack {
            Circle().fill(.ultraThinMaterial).frame(width: 24, height: 24)
            Circle().fill(Color.black.opacity(0.45)).frame(width: 24, height: 24)
            Image(systemName: "minus").font(.system(size: 11, weight: .black)).foregroundColor(.white)
            Circle().stroke(Color.white.opacity(0.32), lineWidth: 0.8).frame(width: 24, height: 24)
        }
        .shadow(color: Color.black.opacity(0.2), radius: 6, x: 0, y: 3)
    }
}

// MARK: - App 图标通用组件
struct AppIcon: View {
    var icon: String
    var color: Color
    var title: String? = nil
    var textColor: Color = .white
    var customImageData: Data? = nil
    var action: () -> Void
    
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        VStack(spacing: 3) {
            Button(action: action) {
                Group {
                    if let uiImage = ImageBitmapCache.shared.image(from: customImageData) {
                        Image(uiImage: uiImage)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 60, height: 60)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .overlay(
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
                            )
                    } else {
                        Image(systemName: icon)
                            .font(.system(size: 35))
                            .foregroundColor(.white)
                            .frame(width: 60, height: 60)
                            .background(color)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    }
                }
            }
            if let title = title {
                Text(translator.translate(title))
                    .font(.caption)
                    .fontWeight(appearance.systemFontWeight)
                    .foregroundColor(textColor)
            }
        }
    }
}
