// MARK: - 7. WidgetKorean (4×2 韩系寄语组件：自适应高度严丝合缝版)
import SwiftUI
import PhotosUI

class KoreanMessageWidgetManager: ObservableObject {
    static let shared = KoreanMessageWidgetManager()
    
    private let photoIdKey = "App_Widget_Korean_ImageID"
    private let headerKey = "App_Widget_Korean_HeaderTitle"
    private let nameKey = "App_Widget_Korean_ProfileName"
    private let leftTextKey = "App_Widget_Korean_FirstLeftText"
    private let rightTextKey = "App_Widget_Korean_FirstRightText"
    private let secondTextKey = "App_Widget_Korean_SecondText"
    private let addedKey = "App_Widget_Korean_IsAdded"
    private let pageKey = "App_Widget_Korean_PagePosition"
    private let rowKey = "App_Widget_Korean_RowPosition"
    
    private let kTransparentKey = "App_Widget_Korean_IsTransparent"
    private let kBgColorKey = "App_Widget_Korean_BgColor"
    private let kBoxStyleKey = "App_Widget_Korean_BoxStyle"
    private let kPinPreviewKey = "App_Widget_Korean_IsPinPreview"
    
    private let kBoxBorderWidthKey = "App_Widget_Korean_BoxBorderWidth"
    private let kBoxBorderColorKey = "App_Widget_Korean_BoxBorderColor"
    
    private let kHeaderColorKey = "App_Widget_Korean_HeaderColor"
    private let kNameColorKey = "App_Widget_Korean_NameColor"
    private let kLeftColorKey = "App_Widget_Korean_LeftColor"
    private let kRightColorKey = "App_Widget_Korean_RightColor"
    private let kSecondColorKey = "App_Widget_Korean_SecondColor"
    private let kSealColorKey = "App_Widget_Korean_SealColor"
    
    private let kHeaderSizeKey = "App_Widget_Korean_HeaderSize"
    private let kNameSizeKey = "App_Widget_Korean_NameSize"
    private let kLeftSizeKey = "App_Widget_Korean_LeftSize"
    private let kRightSizeKey = "App_Widget_Korean_RightSize"
    private let kSecondSizeKey = "App_Widget_Korean_SecondSize"
    
    private let kHeaderWeightKey = "App_Widget_Korean_HeaderWeight"
    private let kNameWeightKey = "App_Widget_Korean_NameWeight"
    private let kLeftWeightKey = "App_Widget_Korean_LeftWeight"
    private let kRightWeightKey = "App_Widget_Korean_RightWeight"
    private let kSecondWeightKey = "App_Widget_Korean_SecondWeight"
    
    private let kAvatarSizeKey = "App_Widget_Korean_AvatarSize"
    private let kSealSizeKey = "App_Widget_Korean_SealSize"
    
    @Published var widgetImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: photoIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: widgetImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.photoIdKey)
            }
        }
    }
    
    @Published var headerTitle: String { didSet { UserDefaults.standard.set(headerTitle, forKey: headerKey) } }
    @Published var profileName: String { didSet { UserDefaults.standard.set(profileName, forKey: nameKey) } }
    @Published var firstBarLeftText: String { didSet { UserDefaults.standard.set(firstBarLeftText, forKey: leftTextKey) } }
    @Published var firstBarRightText: String { didSet { UserDefaults.standard.set(firstBarRightText, forKey: rightTextKey) } }
    @Published var secondBarText: String { didSet { UserDefaults.standard.set(secondBarText, forKey: secondTextKey) } }
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var isTransparentBackground: Bool { didSet { UserDefaults.standard.set(isTransparentBackground, forKey: kTransparentKey) } }
    @Published var backgroundColorHex: String { didSet { UserDefaults.standard.set(backgroundColorHex, forKey: kBgColorKey) } }
    @Published var boxStyle: String { didSet { UserDefaults.standard.set(boxStyle, forKey: kBoxStyleKey) } }
    @Published var isPinPreviewToTop: Bool { didSet { UserDefaults.standard.set(isPinPreviewToTop, forKey: kPinPreviewKey) } }
    
    @Published var boxBorderWidth: Double { didSet { UserDefaults.standard.set(boxBorderWidth, forKey: kBoxBorderWidthKey) } }
    @Published var boxBorderColorHex: String { didSet { UserDefaults.standard.set(boxBorderColorHex, forKey: kBoxBorderColorKey) } }
    
    @Published var headerColorHex: String { didSet { UserDefaults.standard.set(headerColorHex, forKey: kHeaderColorKey) } }
    @Published var nameColorHex: String { didSet { UserDefaults.standard.set(nameColorHex, forKey: kNameColorKey) } }
    @Published var leftColorHex: String { didSet { UserDefaults.standard.set(leftColorHex, forKey: kLeftColorKey) } }
    @Published var rightColorHex: String { didSet { UserDefaults.standard.set(rightColorHex, forKey: kRightColorKey) } }
    @Published var secondColorHex: String { didSet { UserDefaults.standard.set(secondColorHex, forKey: kSecondColorKey) } }
    @Published var sealColorHex: String { didSet { UserDefaults.standard.set(sealColorHex, forKey: kSealColorKey) } }
    
    @Published var headerSize: Double { didSet { UserDefaults.standard.set(headerSize, forKey: kHeaderSizeKey) } }
    @Published var nameSize: Double { didSet { UserDefaults.standard.set(nameSize, forKey: kNameSizeKey) } }
    @Published var leftSize: Double { didSet { UserDefaults.standard.set(leftSize, forKey: kLeftSizeKey) } }
    @Published var rightSize: Double { didSet { UserDefaults.standard.set(rightSize, forKey: kRightSizeKey) } }
    @Published var secondSize: Double { didSet { UserDefaults.standard.set(secondSize, forKey: kSecondSizeKey) } }
    
    @Published var headerWeightName: String { didSet { UserDefaults.standard.set(headerWeightName, forKey: kHeaderWeightKey) } }
    @Published var nameWeightName: String { didSet { UserDefaults.standard.set(nameWeightName, forKey: kNameWeightKey) } }
    @Published var leftWeightName: String { didSet { UserDefaults.standard.set(leftWeightName, forKey: kLeftWeightKey) } }
    @Published var rightWeightName: String { didSet { UserDefaults.standard.set(rightWeightName, forKey: kRightWeightKey) } }
    @Published var secondWeightName: String { didSet { UserDefaults.standard.set(secondWeightName, forKey: kSecondWeightKey) } }
    
    @Published var avatarSize: Double { didSet { UserDefaults.standard.set(avatarSize, forKey: kAvatarSizeKey) } }
    @Published var sealSize: Double { didSet { UserDefaults.standard.set(sealSize, forKey: kSealSizeKey) } }
    
    var backgroundColor: Color { Color(hex: backgroundColorHex) }
    var boxBorderColor: Color { Color(hex: boxBorderColorHex) }
    var headerColor: Color { Color(hex: headerColorHex) }
    var nameColor: Color { Color(hex: nameColorHex) }
    var leftColor: Color { Color(hex: leftColorHex) }
    var rightColor: Color { Color(hex: rightColorHex) }
    var secondColor: Color { Color(hex: secondColorHex) }
    var sealColor: Color { Color(hex: sealColorHex) }
    
    var headerWeight: Font.Weight { Font.Weight.from(name: headerWeightName) }
    var nameWeight: Font.Weight { Font.Weight.from(name: nameWeightName) }
    var leftWeight: Font.Weight { Font.Weight.from(name: leftWeightName) }
    var rightWeight: Font.Weight { Font.Weight.from(name: rightWeightName) }
    var secondWeight: Font.Weight { Font.Weight.from(name: secondWeightName) }
    
    init() {
        if let savedId = UserDefaults.standard.string(forKey: photoIdKey) {
            self.widgetImageData = LocalImageStore.shared.load(id: savedId)
        }
        self.headerTitle = "보내기 ♡"
        self.profileName = "디저트"
        self.firstBarLeftText = "고생 끝에 낙이 온다"
        self.firstBarRightText = "슬프다"
        self.secondBarText = "kunoouc"
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.object(forKey: rowKey) != nil ? UserDefaults.standard.integer(forKey: rowKey) : 4
        self.widgetRow = min(max(0, rawRow), 4)
        self.isTransparentBackground = false
        self.backgroundColorHex = "#EDEDF2"
        self.boxStyle = "shadow"
        self.isPinPreviewToTop = true
        self.boxBorderWidth = UserDefaults.standard.object(forKey: kBoxBorderWidthKey) != nil ? UserDefaults.standard.double(forKey: kBoxBorderWidthKey) : 0.9
        self.boxBorderColorHex = UserDefaults.standard.string(forKey: kBoxBorderColorKey) ?? "#E5E5EA"
        self.headerColorHex = "#000000"
        self.nameColorHex = "#000000"
        self.leftColorHex = "#000000"
        self.rightColorHex = "#8E8E93"
        self.secondColorHex = "#000000"
        self.sealColorHex = "#8E8E93"
        self.headerSize = 9.5
        self.nameSize = 11.5
        self.leftSize = 12.0
        self.rightSize = 11.0
        self.secondSize = 12.5
        self.headerWeightName = UserDefaults.standard.string(forKey: kHeaderWeightKey) ?? "bold"
        self.nameWeightName = UserDefaults.standard.string(forKey: kNameWeightKey) ?? "semibold"
        self.leftWeightName = UserDefaults.standard.string(forKey: kLeftWeightKey) ?? "regular"
        self.rightWeightName = UserDefaults.standard.string(forKey: kRightWeightKey) ?? "regular"
        self.secondWeightName = UserDefaults.standard.string(forKey: kSecondWeightKey) ?? "regular"
        self.avatarSize = 32.0
        self.sealSize = 23.0
    }
}

struct KoreanMessageWidget4x2View: View {
    var imageData: Data?
    var isTransparent: Bool = false
    var backgroundColor: Color = Color(UIColor.systemGray6)
    var showDashedBorder: Bool = false
    var boxStyle: String = "shadow"
    var boxBorderWidth: Double = 0.9
    var boxBorderColor: Color = Color.primary.opacity(0.12)
    var headerTitle: String = "보내기 ♡"
    var headerColor: Color = .primary
    var headerSize: Double = 9.5
    var headerWeight: Font.Weight = .bold
    var profileName: String = "디저트"
    var nameColor: Color = .primary
    var nameSize: Double = 11.5
    var nameWeight: Font.Weight = .semibold
    var avatarSize: Double = 32.0
    var firstBarLeftText: String = "고생 끝에 낙이 온다"
    var firstBarLeftColor: Color = .primary
    var firstBarLeftSize: Double = 12.0
    var firstBarLeftWeight: Font.Weight = .regular
    var firstBarRightText: String = "슬프다"
    var firstBarRightColor: Color = .secondary
    var firstBarRightSize: Double = 11.0
    var firstBarRightWeight: Font.Weight = .regular
    var secondBarText: String = "kunoouc"
    var secondBarColor: Color = .primary
    var secondBarSize: Double = 12.5
    var secondBarWeight: Font.Weight = .regular
    var sealColor: Color = .secondary
    var sealSize: Double = 23.0
    var isEditing: Bool = false
    var onDelete: (() -> Void)? = nil
    
    init(manager: KoreanMessageWidgetManager = .shared, showDashedBorder: Bool = false, isEditing: Bool = false, onDelete: (() -> Void)? = nil) {
        self.imageData = manager.widgetImageData
        self.isTransparent = manager.isTransparentBackground
        self.backgroundColor = manager.backgroundColor
        self.showDashedBorder = showDashedBorder
        self.boxStyle = manager.boxStyle
        self.boxBorderWidth = manager.boxBorderWidth
        self.boxBorderColor = manager.boxBorderColor
        self.headerTitle = manager.headerTitle
        self.headerColor = manager.headerColor
        self.headerSize = manager.headerSize
        self.headerWeight = manager.headerWeight
        self.profileName = manager.profileName
        self.nameColor = manager.nameColor
        self.nameSize = manager.nameSize
        self.nameWeight = manager.nameWeight
        self.avatarSize = manager.avatarSize
        self.firstBarLeftText = manager.firstBarLeftText
        self.firstBarLeftColor = manager.leftColor
        self.firstBarLeftSize = manager.leftSize
        self.firstBarLeftWeight = manager.leftWeight
        self.firstBarRightText = manager.firstBarRightText
        self.firstBarRightColor = manager.rightColor
        self.firstBarRightSize = manager.rightSize
        self.firstBarRightWeight = manager.rightWeight
        self.secondBarText = manager.secondBarText
        self.secondBarColor = manager.secondColor
        self.secondBarSize = manager.secondSize
        self.secondBarWeight = manager.secondWeight
        self.sealColor = manager.sealColor
        self.sealSize = manager.sealSize
        self.isEditing = isEditing
        self.onDelete = onDelete
    }
    
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            Group {
                if isTransparent { Color.clear } else { backgroundColor }
            }
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            
            VStack(alignment: .leading, spacing: 5.5) {
                Text(translator.translate(headerTitle))
                    .font(.system(size: CGFloat(headerSize)))
                    .fontWeight(effectiveWeight(headerWeight))
                    .foregroundColor(headerColor)
                    .padding(.top, 1)
                    .padding(.leading, 3)
                
                HStack(spacing: 7) {
                    Group {
                        if let data = imageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                            Image(uiImage: uiImage).resizable().scaledToFill()
                        } else {
                            ZStack {
                                Color.white
                                Image(systemName: "person.fill")
                                    .font(.system(size: CGFloat(avatarSize * 0.45)))
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    .frame(width: CGFloat(avatarSize), height: CGFloat(avatarSize))
                    .clipShape(RoundedRectangle(cornerRadius: CGFloat(avatarSize * 0.2), style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: CGFloat(avatarSize * 0.2), style: .continuous)
                            .stroke(Color.primary.opacity(0.06), lineWidth: 0.8)
                    )
                    
                    Text(translator.translate(profileName))
                        .font(.system(size: CGFloat(nameSize)))
                        .fontWeight(effectiveWeight(nameWeight))
                        .foregroundColor(nameColor)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(.secondary.opacity(0.7))
                }
                .padding(.horizontal, 3)
                
                HStack {
                    Text(translator.translate(firstBarLeftText))
                        .font(.system(size: CGFloat(firstBarLeftSize)))
                        .fontWeight(effectiveWeight(firstBarLeftWeight))
                        .foregroundColor(firstBarLeftColor)
                    Spacer()
                    Text(translator.translate(firstBarRightText))
                        .font(.system(size: CGFloat(firstBarRightSize)))
                        .fontWeight(effectiveWeight(firstBarRightWeight))
                        .foregroundColor(firstBarRightColor)
                }
                .padding(.horizontal, 13)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
                .applyBoxStyle(style: boxStyle, cornerRadius: 11, borderWidth: boxBorderWidth, borderColor: boxBorderColor)
                
                HStack(spacing: 8) {
                    HStack {
                        Text(translator.translate(secondBarText))
                            .font(.system(size: CGFloat(secondBarSize)))
                            .fontWeight(effectiveWeight(secondBarWeight))
                            .foregroundColor(secondBarColor)
                        Spacer()
                    }
                    .padding(.horizontal, 13)
                    .frame(maxWidth: .infinity)
                    .frame(height: 38)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                    .applyBoxStyle(style: boxStyle, cornerRadius: 10, borderWidth: boxBorderWidth, borderColor: boxBorderColor)
                    
                    ZStack {
                        Circle()
                            .stroke(sealColor.opacity(0.55), lineWidth: 1.0)
                            .frame(width: CGFloat(sealSize), height: CGFloat(sealSize))
                        Text("응")
                            .font(.system(size: CGFloat(sealSize * 0.46), weight: .bold))
                            .foregroundColor(sealColor)
                    }
                    .padding(.trailing, 2)
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal, 13)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(
                    isTransparent ? (showDashedBorder ? Color.secondary.opacity(0.4) : Color.clear) : Color.primary.opacity(0.08),
                    style: StrokeStyle(lineWidth: 1, dash: (isTransparent && showDashedBorder) ? [5, 4] : [])
                )
                .allowsHitTesting(false)
            
            if isEditing, let onDelete = onDelete {
                Button(action: onDelete) { WidgetDeleteBadge() }
                    .padding(8)
                    .transition(.scale.combined(with: .opacity))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
        // 🌟 核心修改：允许自适应填满父级计算的高度，绝不自我写死 160
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct EditKoreanWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var widgetManager = KoreanMessageWidgetManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @State private var selectedPhotoItem: PhotosPickerItem? = nil
    @ObservedObject var appearance = SystemAppearance.shared
    
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let bgPresets = ["#EDEDF2", "#FFFFFF", "#1C1C1E", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#D0E1FD", "#E8DFF5"]
    private let borderPresets = ["#E5E5EA", "#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let boxStyleOptions = [("柔和阴影", "shadow"), ("精致描边", "border"), ("纯平无样式", "none")]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if widgetManager.isPinPreviewToTop {
                    previewCardView.background(Color(UIColor.systemGroupedBackground))
                    Divider()
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !widgetManager.isPinPreviewToTop {
                            previewCardView.padding(.top, 8)
                        }
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("背景与形态".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Toggle(isOn: $widgetManager.isPinPreviewToTop) {
                                Label("固定顶部预览".tr, systemImage: "pin.fill").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            Divider()
                            Toggle(isOn: $widgetManager.isTransparentBackground) {
                                Label("背景透明模式".tr, systemImage: "circle.lefthalf.filled").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            if !widgetManager.isTransparentBackground {
                                Divider()
                                WidgetColorPaletteRow(title: "组件背景底色".tr, selectedHex: widgetManager.backgroundColorHex, presets: bgPresets, currentColor: widgetManager.backgroundColor, onSelectHex: { widgetManager.backgroundColorHex = $0 }, onPickColor: { widgetManager.backgroundColorHex = $0.toHex() })
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 8) {
                                Text("白框装饰效果".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                HStack(spacing: 8) {
                                    ForEach(boxStyleOptions, id: \.1) { item in
                                        let isSelected = widgetManager.boxStyle == item.1
                                        Button(action: {
                                            withAnimation(.easeInOut(duration: 0.18)) { widgetManager.boxStyle = item.1 }
                                        }) {
                                            Text(item.0.tr)
                                                .font(.system(size: 12, weight: isSelected ? .semibold : appearance.systemFontWeight))
                                                .padding(.horizontal, 12).padding(.vertical, 6)
                                                .background(isSelected ? Color.blue : Color(UIColor.tertiarySystemFill))
                                                .foregroundColor(isSelected ? .white : .primary)
                                                .clipShape(Capsule())
                                        }
                                    }
                                }
                                if widgetManager.boxStyle == "border" {
                                    Divider().padding(.top, 4)
                                    VStack(alignment: .leading, spacing: 6) {
                                        HStack {
                                            Text("白框描边粗细".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                            Spacer()
                                            Text(String(format: "%.1f pt", widgetManager.boxBorderWidth)).font(.caption).foregroundColor(.secondary)
                                        }
                                        Slider(value: $widgetManager.boxBorderWidth, in: 0.1...5.0, step: 0.1)
                                    }
                                    Divider()
                                    WidgetColorPaletteRow(title: "白框描边颜色".tr, selectedHex: widgetManager.boxBorderColorHex, presets: borderPresets, currentColor: widgetManager.boxBorderColor, onSelectHex: { widgetManager.boxBorderColorHex = $0 }, onPickColor: { widgetManager.boxBorderColorHex = $0.toHex() })
                                }
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16).padding(.top, widgetManager.isPinPreviewToTop ? 12 : 0)
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("头像与印章".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            PhotosPicker(selection: $selectedPhotoItem, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    Label("更换头像照片".tr, systemImage: "photo.badge.plus").font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("头像大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(widgetManager.avatarSize)) pt").font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.avatarSize, in: 20...44, step: 1)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("印章图标大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(widgetManager.sealSize)) pt").font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sealSize, in: 14...36, step: 1)
                            }
                            Divider()
                            WidgetColorPaletteRow(title: "印章图标颜色".tr, selectedHex: widgetManager.sealColorHex, presets: textColors, currentColor: widgetManager.sealColor, onSelectHex: { widgetManager.sealColorHex = $0 }, onPickColor: { widgetManager.sealColorHex = $0.toHex() })
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        WidgetTextSectionEditor(sectionTitle: "顶部小标题".tr, placeholder: "如：보내기 ♡", text: $widgetManager.headerTitle, size: $widgetManager.headerSize, minSize: 7, maxSize: 18, selectedWeightName: $widgetManager.headerWeightName, selectedHex: widgetManager.headerColorHex, currentColor: widgetManager.headerColor, onSelectHex: { widgetManager.headerColorHex = $0 }, onPickColor: { widgetManager.headerColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "个人昵称".tr, placeholder: "如：디저트", text: $widgetManager.profileName, size: $widgetManager.nameSize, minSize: 9, maxSize: 20, selectedWeightName: $widgetManager.nameWeightName, selectedHex: widgetManager.nameColorHex, currentColor: widgetManager.nameColor, onSelectHex: { widgetManager.nameColorHex = $0 }, onPickColor: { widgetManager.nameColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "第一排左侧寄语".tr, placeholder: "如：고생 끝에 낙이 온다", text: $widgetManager.firstBarLeftText, size: $widgetManager.leftSize, minSize: 9, maxSize: 18, selectedWeightName: $widgetManager.leftWeightName, selectedHex: widgetManager.leftColorHex, currentColor: widgetManager.leftColor, onSelectHex: { widgetManager.leftColorHex = $0 }, onPickColor: { widgetManager.leftColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "第一排右侧标签".tr, placeholder: "如：슬프다", text: $widgetManager.firstBarRightText, size: $widgetManager.rightSize, minSize: 8, maxSize: 16, selectedWeightName: $widgetManager.rightWeightName, selectedHex: widgetManager.rightColorHex, currentColor: widgetManager.rightColor, onSelectHex: { widgetManager.rightColorHex = $0 }, onPickColor: { widgetManager.rightColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "第二排签名/账号".tr, placeholder: "如：kunoouc", text: $widgetManager.secondBarText, size: $widgetManager.secondSize, minSize: 9, maxSize: 18, selectedWeightName: $widgetManager.secondWeightName, selectedHex: widgetManager.secondColorHex, currentColor: widgetManager.secondColor, onSelectHex: { widgetManager.secondColorHex = $0 }, onPickColor: { widgetManager.secondColorHex = $0.toHex() })
                    }
                    .padding(.bottom, 32)
                }
                .background(Color(UIColor.systemGroupedBackground))
            }
            .navigationTitle("定制寄语卡片".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
        }
        .presentationDetents([.medium, .large])
        .task(id: selectedPhotoItem) {
            if let data = try? await selectedPhotoItem?.loadTransferable(type: Data.self) {
                withAnimation(.easeInOut(duration: 0.25)) { widgetManager.widgetImageData = data }
            }
        }
    }
    
    private var previewCardView: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(Color(UIColor.secondarySystemGroupedBackground))
                .frame(height: 180)
            
            KoreanMessageWidget4x2View(
                manager: widgetManager,
                showDashedBorder: true
            )
            .frame(height: 160) // 弹窗定制页内保持 160 预览
            .padding(.horizontal, 16)
        }
        .padding(.horizontal, 16).padding(.top, 10).padding(.bottom, 10)
    }
}

extension View {
    @ViewBuilder
    func applyBoxStyle(style: String, cornerRadius: CGFloat, borderWidth: Double = 0.9, borderColor: Color = Color.primary.opacity(0.12)) -> some View {
        switch style {
        case "border":
            self.overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(borderColor, lineWidth: CGFloat(borderWidth))
            )
        case "shadow":
            self.shadow(color: Color.black.opacity(0.035), radius: 2.5, x: 0, y: 1.2)
        default:
            self
        }
    }
}

extension WidgetRegistry {
    func registerKoreanWidget() {
        let mgr = KoreanMessageWidgetManager.shared
        registerWidget(
            id: "korean",
            title: "widget_korean_title",
            subtitle: "sub_korean",
            badge: "4×2",
            manager: mgr,
            desktopView: {
                KoreanMessageWidget4x2View(manager: mgr).padding(.horizontal, 16)
            },
            previewView: {
                KoreanMessageWidget4x2View(manager: mgr).frame(height: 160).padding(.horizontal, 16)
            },
            editSheetView: { show in
                EditKoreanWidgetSheet(isPresented: show)
            }
        )
    }
}
