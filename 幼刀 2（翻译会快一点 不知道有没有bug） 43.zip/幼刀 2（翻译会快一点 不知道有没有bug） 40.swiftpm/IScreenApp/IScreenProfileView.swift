// 📄 新文件：IScreenProfileView.swift
import SwiftUI

struct IScreenProfileView: View {
    @ObservedObject var viewModel: IScreenViewModel
    @ObservedObject var appearance = SystemAppearance.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 20) {
                VStack(spacing: 16) {
                    HStack(spacing: 16) {
                        Image(systemName: "person.crop.circle.fill").font(.size64).foregroundColor(.blue)
                        VStack(alignment: .leading, spacing: 4) {
                            if viewModel.isEditingProfile {
                                TextField("输入昵称".tr, text: $viewModel.userName).font(.title3.weight(.bold)).textFieldStyle(.roundedBorder)
                            } else {
                                HStack {
                                    Text(translator.translate(viewModel.userName)).font(.system(size: 19, weight: appearance.systemFontWeight))
                                    Text("PRO").font(.system(size: 10, weight: .bold)).padding(.horizontal, 6).padding(.vertical, 2).background(Color.blue).foregroundColor(.white).clipShape(Capsule())
                                }
                            }
                            Text("UID: \(viewModel.userUID)").font(.caption).foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    VStack(alignment: .leading, spacing: 6) {
                        Text("个人简介".tr).font(.caption).foregroundColor(.secondary)
                        if viewModel.isEditingProfile {
                            TextField("输入个性简介".tr, text: $viewModel.userBio).font(.subheadline).textFieldStyle(.roundedBorder)
                        } else {
                            Text(translator.translate(viewModel.userBio)).font(.system(size: 15, weight: appearance.systemFontWeight)).foregroundColor(.primary)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading)
                    
                    Divider()
                    
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) { viewModel.isEditingProfile.toggle() }
                    }) {
                        HStack {
                            Image(systemName: viewModel.isEditingProfile ? "checkmark.circle.fill" : "pencil.circle.fill")
                            Text(viewModel.isEditingProfile ? "保存资料".tr : "编辑资料".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                        }
                        .frame(maxWidth: .infinity).padding(.vertical, 10).background(viewModel.isEditingProfile ? Color.green : Color(UIColor.secondarySystemFill)).foregroundColor(viewModel.isEditingProfile ? .white : .primary).cornerRadius(12)
                    }
                }.padding(20).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(22).padding(.horizontal, 16).padding(.top, 14)
                
                VStack(spacing: 0) {
                    accountSettingRow(icon: "icloud.and.arrow.up.fill", title: "云端备份与恢复".tr, color: .blue)
                    Divider().padding(.leading, 52)
                    accountSettingRow(icon: "paintbrush.fill", title: "小组件刷新频率".tr, color: .orange)
                    Divider().padding(.leading, 52)
                    accountSettingRow(icon: "info.circle.fill", title: "关于 iScreen".tr, color: .blue)
                }.background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(20).padding(.horizontal, 16)
            }.padding(.bottom, 20)
        }
    }
    
    private func accountSettingRow(icon: String, title: String, color: Color) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 16, weight: .semibold)).foregroundColor(.white).frame(width: 30, height: 30).background(color).clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
            Text(title).font(.system(size: 15, weight: appearance.systemFontWeight))
            Spacer()
            Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary.opacity(0.5))
        }.padding(.horizontal, 16).padding(.vertical, 14)
    }
}
